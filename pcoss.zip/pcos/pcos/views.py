from django.shortcuts import render, redirect
from sklearn.preprocessing import LabelEncoder
from keras.models import load_model
from django.http import JsonResponse
import pickle
import joblib
import pandas as pd

def home(request):
    return render(request, 'index.html')

def process_form(request):
    if request.method == 'POST':
        PeriodLength = request.POST.get('input1')
        Overweight = request.POST.get('input2')
        lossweightgain = request.POST.get('input3')
        irregularormissedperiods = request.POST.get('input4')
        Acneorskintags = request.POST.get('input5')
        hairloss = request.POST.get('input6')
        Darkpatches = request.POST.get('input7')
        moreMoodSwings = request.POST.get('input8')
        exerciseperweek = request.POST.get('input9')
        eatoutsideperweek = request.POST.get('input10')
        cannedfoodoften = request.POST.get('input11')

        print( PeriodLength,Overweight,lossweightgain,irregularormissedperiods,Acneorskintags,hairloss,Darkpatches,moreMoodSwings,exerciseperweek,eatoutsideperweek,cannedfoodoften)


        with open('model.pkl','rb') as f:
            model = pickle.load(f)


        
        data = [[PeriodLength,Overweight,lossweightgain,irregularormissedperiods,Acneorskintags,hairloss,Darkpatches,moreMoodSwings,exerciseperweek,eatoutsideperweek,cannedfoodoften]]
        print(data)
        feature_name = ['hairloss', 'moreMoodSwings', 'Acneorskintags', 'Darkpatches',
       'lossweightgain/weightloss', 'cannedfoodoften',
       'irregularormissedperiods', 'exerciseperweek', 'eatoutsideperweek',
       'PeriodLength', 'Overweight']
        data = pd.DataFrame(data, feature_name) 
        prediction = model.predict(data)
        print(prediction)


        result = {'prediction':prediction[0]}
        return render(request, 'index.html',result)
    return redirect(request, 'index.html')